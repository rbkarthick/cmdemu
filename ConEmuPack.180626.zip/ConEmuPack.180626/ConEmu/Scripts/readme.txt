You may use this folder to store your scripts to be available via `%PATH%`.

It is added to environment PATH variable (for processes started in ConEmu)
on the `Environment` settings page:
https://conemu.github.io/en/SettingsEnvironment.html
