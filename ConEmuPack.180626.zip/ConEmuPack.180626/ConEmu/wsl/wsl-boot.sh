#/bin/sh
uname -a
./256colors2.pl
cd ~
bash -l -i
